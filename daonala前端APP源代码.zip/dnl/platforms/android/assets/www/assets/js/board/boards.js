/**
 * Created by 翔 on 2015/6/3.
 */
function init_borad()
{
    $(".boardPanel").height($("#content").height());
}