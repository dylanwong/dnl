/**
 * Created by wyy on 2015-06-19.
 */

function initOwnerDataBoard(){

}