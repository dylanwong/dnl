/**
 * Created by wyy on 2015-05-27.
 */

/*

function initTraceInfo(){

}

function initTraceInfo2(){

}*/
