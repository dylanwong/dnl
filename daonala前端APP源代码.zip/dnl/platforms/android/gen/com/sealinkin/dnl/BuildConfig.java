/** Automatically generated file. DO NOT MODIFY */
package com.sealinkin.dnl;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}