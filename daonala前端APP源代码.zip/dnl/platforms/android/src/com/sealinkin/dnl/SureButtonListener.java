package com.sealinkin.dnl;

import android.content.DialogInterface;

public class SureButtonListener implements android.content.DialogInterface.OnClickListener{

	@Override
	public void onClick(DialogInterface dialog, int which) {
		// TODO Auto-generated method stub
		System.exit(0);
	}

}
